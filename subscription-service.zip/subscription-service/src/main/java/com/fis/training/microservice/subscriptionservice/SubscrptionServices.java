package com.fis.training.microservice.subscriptionservice;
import java.util.Optional;
import com.bookservice.Book;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
@Transactional
public class SubscrptionServices {

	@Autowired
	private SubscrptionRepo repo;
	@Autowired
	private RestTemplate restTemplate;
	
	public List<Subscription> getSubscriptions(String subscriberName){
		if(subscriberName!=null) {
			return repo.findBySubscriberName(subscriberName);
		}
		return repo.findAll();
	}

	/*
	 * public List<Subscription> listAll() { return repo.findAll(); }
	 * 
	 * public Subscription get(String id) { return repo.findByBookId(id); }
	 */
	
	public Subscription createSubscription(Subscription subscription) {
		ResponseEntity<Book[]> response= restTemplate.getForEntity("http://BookService/books", Book[].class);
		List<Book> books= Arrays.asList(response.getBody());
		
		Optional<Book> book= books.stream().filter(b->b.getBookId().equals(subscription.getBookId())).findFirst();
		if(book.isPresent() && book.get().getCopiesAvailable()>0) {
			return repo.save(subscription);
		}else {
			throw new RuntimeException("Book not available for subscription");
		}
	}

}
