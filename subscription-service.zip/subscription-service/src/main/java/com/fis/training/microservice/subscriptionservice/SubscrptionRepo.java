package com.fis.training.microservice.subscriptionservice;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface SubscrptionRepo extends JpaRepository<Subscription, String> {

	Subscription findByBookId(String id);
	List<Subscription> findBySubscriberName(String subscriberName);

}
