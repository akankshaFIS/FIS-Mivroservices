package com.fis.training.microservice.subscriptionservice;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/subscriptions")
public class SubscrptionController {
	
	@Autowired
    private SubscrptionServices subscrptionServices;
	
	@GetMapping("/subscription")
	public List<Subscription> getSubscription(@RequestParam(required=false) String subscriberName) {
	    return subscrptionServices.getSubscriptions(subscriberName);
	}
	
	/*
	 * @GetMapping("/subscription/{id}") public ResponseEntity<Subscription>
	 * get(@PathVariable String id) { try { Subscription subscrption =
	 * service.get(id); return new ResponseEntity<Subscription>(subscrption,
	 * HttpStatus.OK); } catch (NoSuchElementException e) { return new
	 * ResponseEntity<Subscription>(HttpStatus.NOT_FOUND); }
	 * 
	 * }
	 */
	/*
	 * @GetMapping("/save") public String save() { return service.save(null); }
	 */
	
	@PostMapping
	public ResponseEntity<?> createSubscription(@RequestBody Subscription subscription){
		try {
			Subscription newSubscription =subscrptionServices.createSubscription(subscription);
			return new ResponseEntity<>(newSubscription, HttpStatus.CREATED);
		}catch(Exception e) {
			return new ResponseEntity<>(e.getMessage(), HttpStatus.UNPROCESSABLE_ENTITY);
		}
	}
		
}

